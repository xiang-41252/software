#ifndef DATACACHE_TESTS_H
#define DATACACHE_TESTS_H

void add_datacache_tests(Suite *s);

#endif
