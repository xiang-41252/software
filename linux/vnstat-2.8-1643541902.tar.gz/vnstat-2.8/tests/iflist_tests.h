#ifndef IFLIST_TESTS_H
#define IFLIST_TESTS_H

void add_iflist_tests(Suite *s);

#endif
